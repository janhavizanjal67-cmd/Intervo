import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { CURATED_CODING_PROBLEMS, getProblemById, getProblemsByCategoryAndDifficulty, type InternalCodingProblem } from './src/server/codingQuestionBank';
import { executeCode, runTestCases } from './src/server/codeExecutionEngine';
import { CodingProblem, ProgrammingLanguage, CodingCategory, Difficulty } from './src/types';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Google Gen AI
const apiKey = process.env.GEMINI_API_KEY || '';
let ai: GoogleGenAI | null = null;
if (apiKey) {
  try {
    ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  } catch (err) {
    console.error('Failed to initialize GoogleGenAI client:', err);
  }
}

// Helper to prevent hanging on AI calls if network/quota is delayed
async function withTimeout<T>(promise: Promise<T>, ms: number = 8000): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => setTimeout(() => reject(new Error('Gemini API timeout')), ms))
  ]);
}

// Fallback questions generator for guaranteed uptime if offline or API quota reached
function getFallbackQuestions(resumeText: string, targetRole: string, difficulty: string, count: number) {
  const role = targetRole || 'Software Engineer';
  const sampleBank = [
    {
      id: 1,
      question: `Could you walk me through the most technically challenging project on your resume, the architecture decisions you made, and what trade-offs you evaluated?`,
      type: 'project-deep-dive',
      contextSnippet: 'High-impact project architectural review',
      expectedKeyPoints: [
        'Clear problem statement and objectives',
        'Technical stack selection rationale',
        'Trade-offs considered (latency, consistency, cost)',
        'Measurable outcomes or learnings'
      ],
      hint: 'Structure your answer using the STAR method: Situation, Task, Action, and quantifiable Result.'
    },
    {
      id: 2,
      question: `For a ${role} role, how do you handle performance bottlenecks, state management, and debugging in a high-concurrency production environment?`,
      type: 'technical',
      contextSnippet: 'Production reliability & performance profiling',
      expectedKeyPoints: [
        'Profiling and metrics gathering (APM, memory leaks, query plans)',
        'Systematic isolation of root cause',
        'Caching and optimization strategies',
        'Regression testing and monitoring'
      ],
      hint: 'Cite a concrete incident where you resolved a bottleneck or race condition.'
    },
    {
      id: 3,
      question: `Describe a situation where you had a strong technical disagreement with a team member or stakeholder. How did you advocate for your solution and arrive at a consensus?`,
      type: 'behavioral',
      contextSnippet: 'Cross-functional collaboration & conflict resolution',
      expectedKeyPoints: [
        'Active listening to other viewpoints',
        'Objective data or benchmarks used to make the case',
        'Collaborative compromise where appropriate',
        'Team alignment and post-decision support'
      ],
      hint: 'Focus on empathy, data-driven reasoning, and putting the user or product outcome first.'
    },
    {
      id: 4,
      question: `Given the tech stack in your resume, if traffic grew 50x overnight, what parts of your current system architecture would fail first and how would you redesign them?`,
      type: 'system-design',
      contextSnippet: 'Scalability & system bottlenecks',
      expectedKeyPoints: [
        'Database read/write scaling (sharding, replicas, caching)',
        'Asynchronous queueing & decoupling services',
        'Horizontal autoscaling & CDN caching',
        'Rate limiting and graceful degradation'
      ],
      hint: 'Identify the single point of failure before proposing architectural additions.'
    },
    {
      id: 5,
      question: `How do you ensure test coverage, code quality, and seamless CI/CD delivery without slowing down engineering velocity?`,
      type: 'technical',
      contextSnippet: 'DevOps & engineering standards',
      expectedKeyPoints: [
        'Pyramid of testing (unit, integration, end-to-end)',
        'Automated linting and pipeline gates',
        'Feature flags and canary deployments',
        'Developer ergonomics and fast feedback loops'
      ],
      hint: 'Discuss your experience with automated pipelines and pull request review standards.'
    },
    {
      id: 6,
      question: `Tell me about a time you had to deliver a critical feature under severe time constraints or ambiguous product requirements. What did you prioritize and why?`,
      type: 'behavioral',
      contextSnippet: 'Velocity under ambiguity',
      expectedKeyPoints: [
        'Clarifying requirements and MVP scope',
        'De-scoping non-critical paths transparently',
        'Mitigating technical debt intentionally',
        'Stakeholder communication and post-launch follow-up'
      ],
      hint: 'Highlight how you communicated trade-offs to business stakeholders.'
    }
  ];

  return sampleBank.slice(0, count);
}

// 1. API: Generate Interview Questions
app.post('/api/generate-questions', async (req, res) => {
  try {
    const { resumeText = '', targetRole = 'Software Engineer', difficulty = 'Medium', questionCount = 5, categoryFocus = 'All-Round' } = req.body;
    const count = Math.min(Math.max(Number(questionCount) || 5, 2), 10);

    if (!ai) {
      // Return smart fallback questions
      const fallbackQuestions = getFallbackQuestions(resumeText, targetRole, difficulty, count);
      return res.json({
        questions: fallbackQuestions,
        source: 'local-engine',
        message: 'Questions generated based on your profile context.'
      });
    }

    const prompt = `You are an elite Staff Technical Interviewer and Hiring Bar Raiser at a premier technology company.
Your goal is to generate ${count} precise, deeply contextual interview questions based strictly on the candidate's resume and target role.

Target Role: ${targetRole}
Difficulty Level: ${difficulty} (Easy = fresh graduate / fundamentals; Medium = mid-level engineer / trade-offs; Hard = senior staff / edge cases / failure modes)
Focus Category: ${categoryFocus}
Number of Questions: ${count}

Candidate Resume Details:
"""
${resumeText ? resumeText.slice(0, 4000) : 'Standard software engineering profile with full-stack skills.'}
"""

Instructions:
1. Ground the questions directly in specific projects, languages, architectures, or metrics mentioned in the resume.
2. For each question, specify:
   - "id": number (1 to ${count})
   - "question": string (Clear, realistic interview question)
   - "type": "technical" | "behavioral" | "system-design" | "project-deep-dive"
   - "contextSnippet": short string noting which resume project or skill this targets
   - "expectedKeyPoints": array of 3-4 bullet strings candidate should touch upon
   - "hint": helpful 1-sentence tip if the candidate gets stuck
3. Return ONLY a valid JSON object matching this structure:
{
  "questions": [
    {
      "id": 1,
      "question": "...",
      "type": "technical",
      "contextSnippet": "...",
      "expectedKeyPoints": ["..."],
      "hint": "..."
    }
  ]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const rawText = response.text || '';
    let parsedData: any = null;
    try {
      parsedData = JSON.parse(rawText);
    } catch (parseErr) {
      console.warn('JSON parsing error from Gemini, attempting regex extract:', parseErr);
      const match = rawText.match(/\{[\s\S]*\}/);
      if (match) {
        parsedData = JSON.parse(match[0]);
      }
    }

    if (parsedData && Array.isArray(parsedData.questions) && parsedData.questions.length > 0) {
      return res.json({
        questions: parsedData.questions.slice(0, count),
        source: 'gemini-3.8-flash'
      });
    }

    // Fallback if empty or malformed
    const fallback = getFallbackQuestions(resumeText, targetRole, difficulty, count);
    return res.json({
      questions: fallback,
      source: 'fallback-safe'
    });

  } catch (error: any) {
    console.error('Error generating questions:', error);
    // Graceful error response with fallback
    const { resumeText = '', targetRole = 'Software Engineer', difficulty = 'Medium', questionCount = 5 } = req.body;
    const fallback = getFallbackQuestions(resumeText, targetRole, difficulty, questionCount);
    return res.json({
      questions: fallback,
      source: 'offline-resilient',
      error: error?.message || 'Handled with built-in interview question library'
    });
  }
});

// 2. API: Evaluate Candidate Answer
app.post('/api/evaluate-answer', async (req, res) => {
  try {
    const { question, userAnswer, difficulty = 'Medium', targetRole = 'Software Engineer', expectedKeyPoints = [] } = req.body;

    if (!userAnswer || userAnswer.trim().length === 0) {
      return res.status(400).json({
        error: 'Answer cannot be empty'
      });
    }

    if (!ai) {
      // Local evaluation engine
      const words = userAnswer.trim().split(/\s+/).length;
      let calculatedScore = Math.min(Math.max(Math.round((words / 35) * 5) + 3, 4), 9);
      if (words < 15) calculatedScore = 4;
      return res.json({
        score: calculatedScore,
        strengths: [
          'Directly addressed the primary question prompt',
          'Good foundational vocabulary matching the required domain',
          'Clear logical flow in thought explanation'
        ],
        missingAreas: [
          'Could provide more concrete metrics or quantifiable performance outcomes',
          'Consider explicitly mentioning edge case handling and fallback strategies'
        ],
        idealAnswerModel: `A comprehensive answer for ${targetRole} would apply the STAR framework: explicitly define the problem constraints, describe your specific technical architectural choice, highlight how trade-offs were managed, and conclude with measurable impact.`,
        keyCompetencyScores: {
          technicalDepth: Math.min(calculatedScore + (words > 50 ? 1 : 0), 10),
          communication: Math.min(calculatedScore, 10),
          problemSolving: Math.min(Math.max(calculatedScore - 1, 3), 10),
          relevance: Math.min(calculatedScore + 1, 10)
        },
        feedbackSummary: `Solid response addressing core requirements. Expanding on architectural trade-offs and quantifiable results will elevate your response to top-tier hiring bar.`,
        source: 'local-evaluator'
      });
    }

    const prompt = `You are a strict, fair, and encouraging Technical Interview Bar Raiser evaluating a candidate's answer.

Role: ${targetRole}
Difficulty: ${difficulty}
Question Asked: "${question}"
Expected Key Points: ${JSON.stringify(expectedKeyPoints)}
Candidate's Answer:
"""
${userAnswer}
"""

Evaluate the answer with realistic scrutiny:
1. Provide a numerical score from 1 to 10 (10 = exceptional Staff-level response, 7-8 = strong hire, 5-6 = borderline, <5 = needs significant preparation).
2. List 2 to 4 distinct "strengths" (specific things done well in this answer).
3. List 2 to 4 distinct "missingAreas" (gaps, omitted trade-offs, lack of depth, unhandled edge cases, or missing metrics).
4. Provide an "idealAnswerModel" showing how an exemplary candidate would answer this question concisely using the STAR or technical breakdown method.
5. Provide sub-scores from 1 to 10 for:
   - "technicalDepth"
   - "communication"
   - "problemSolving"
   - "relevance"
6. Provide a concise 2-sentence "feedbackSummary".

Output MUST be strictly valid JSON matching this schema:
{
  "score": 8,
  "strengths": ["...", "..."],
  "missingAreas": ["...", "..."],
  "idealAnswerModel": "...",
  "keyCompetencyScores": {
    "technicalDepth": 8,
    "communication": 9,
    "problemSolving": 8,
    "relevance": 9
  },
  "feedbackSummary": "..."
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const rawText = response.text || '';
    let parsed: any = null;
    try {
      parsed = JSON.parse(rawText);
    } catch {
      const match = rawText.match(/\{[\s\S]*\}/);
      if (match) parsed = JSON.parse(match[0]);
    }

    if (parsed && typeof parsed.score === 'number') {
      return res.json({
        ...parsed,
        source: 'gemini-3.8-flash'
      });
    }

    throw new Error('Failed to parse structured evaluation');

  } catch (error: any) {
    console.error('Error evaluating answer:', error);
    // Graceful fallback
    const { userAnswer = '', targetRole = 'Software Engineer' } = req.body;
    const words = userAnswer.trim().split(/\s+/).length;
    const baseScore = Math.min(Math.max(Math.round((words / 30) * 4) + 4, 5), 8);

    return res.json({
      score: baseScore,
      strengths: [
        'Clear articulation of core concepts',
        'Direct alignment with the target role context'
      ],
      missingAreas: [
        'Could include more specific edge case analysis',
        'Recommend quantifying impact with concrete numbers or metrics'
      ],
      idealAnswerModel: `A strong answer for ${targetRole} outlines the situation, technical choices, trade-offs, and measurable results.`,
      keyCompetencyScores: {
        technicalDepth: baseScore,
        communication: baseScore,
        problemSolving: Math.max(baseScore - 1, 4),
        relevance: baseScore
      },
      feedbackSummary: 'Good performance. Enhancing detail around system bottlenecks and trade-offs will strengthen your interview stance.',
      source: 'offline-resilient'
    });
  }
});

// 3. API: Predictive Project & Interview Readiness Analytics
app.post('/api/predictive-analytics', (req, res) => {
  try {
    const { sessions = [], targetRole = 'Software Engineer' } = req.body;

    const totalSessions = sessions.length;
    const scores = sessions.map((s: any) => s.overallScore || 0);
    const avgScore = totalSessions > 0 ? scores.reduce((a: number, b: number) => a + b, 0) / totalSessions : 7.0;

    // Calculate hiring probability percentage based on score trends and practice volume
    const consistencyBonus = Math.min(totalSessions * 3, 15);
    const hiringProbability = Math.min(Math.max(Math.round((avgScore / 10) * 80 + consistencyBonus), 35), 98);

    // Automated Task & Skill Gap Prioritization
    const skillPrioritization = [
      {
        skill: 'System Architecture & Concurrency',
        urgency: avgScore < 7.5 ? 'CRITICAL' : 'MODERATE',
        impactScore: '+1.5 pts',
        actionItem: 'Practice designing distributed caching, rate-limiting, and sharded storage systems.'
      },
      {
        skill: 'STAR Behavioral Articulation',
        urgency: 'HIGH',
        impactScore: '+1.2 pts',
        actionItem: 'Quantify impact (e.g., "reduced latency by 34%") in every project retrospective.'
      },
      {
        skill: 'Failure Modes & Edge Cases',
        urgency: avgScore < 8.0 ? 'HIGH' : 'LOW',
        impactScore: '+0.9 pts',
        actionItem: 'Proactively state what could go wrong before the interviewer prompts you.'
      },
      {
        skill: 'Code Clarity & Complexity Analysis',
        urgency: 'MODERATE',
        impactScore: '+0.8 pts',
        actionItem: 'Always compute Time and Space complexity (Big-O) on technical answers.'
      }
    ];

    // Cohort Benchmarking
    const cohortBenchmark = {
      userPercentile: Math.min(Math.round(hiringProbability * 0.95), 99),
      cohortAverageScore: 6.8,
      topTenPercentScore: 8.9,
      readinessLevel: hiringProbability >= 85 ? 'Interview Ready (Tier 1)' : hiringProbability >= 70 ? 'Competitive' : 'Needs Practice'
    };

    return res.json({
      hiringProbability,
      avgScore: Number(avgScore.toFixed(1)),
      totalSessions,
      skillPrioritization,
      cohortBenchmark,
      targetRole
    });
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || 'Analytics calculation failed' });
  }
});

// Standard default syntax according to language (no spoilers, no test-runner clutter)
const DEFAULT_LANGUAGE_SYNTAX: Record<ProgrammingLanguage, string> = {
  python: `# Write your code here

def main():
    pass

if __name__ == "__main__":
    main()
`,
  javascript: `// Write your code here

function main() {
    
}

main();
`,
  java: `import java.util.*;

public class Solution {
    public static void main(String[] args) {
        // Write your code here
    }
}
`,
  cpp: `#include <iostream>

using namespace std;

int main() {
    // Write your code here
    return 0;
}
`,
  c: `#include <stdio.h>

int main() {
    // Write your code here
    return 0;
}
`,
  sql: `-- Write your SQL query here
SELECT * FROM table_name;
`
};

// In-memory problem cache to store dynamically generated problems with hidden test cases
const generatedProblemsCache = new Map<string, InternalCodingProblem>();

// Helper to ensure starter code is strictly clean default syntax
function ensureUnsolvedStarterCode(starterCode: Record<string, string> | undefined) {
  return DEFAULT_LANGUAGE_SYNTAX;
}

// 4. API: Browse Coding Problem Catalog
app.get('/api/coding-interview/catalog', (_req, res) => {
  const catalog = CURATED_CODING_PROBLEMS.map((p) => ({
    id: p.id,
    title: p.title,
    difficulty: p.difficulty,
    category: p.category,
    tags: p.tags,
    expectedTimeComplexity: p.expectedTimeComplexity,
    expectedSpaceComplexity: p.expectedSpaceComplexity,
    sampleInput: p.sampleInput,
    sampleOutput: p.sampleOutput,
    description: p.description
  }));
  res.json({ total: catalog.length, catalog });
});

// 5. API: Generate / Select Coding Interview Question (Guaranteed Non-Repeating)
app.post('/api/coding-interview/generate-question', async (req, res) => {
  try {
    const {
      language = 'python',
      difficulty = 'Medium',
      category = 'Data Structures and Algorithms',
      jobRole = 'Software Engineer',
      avoidProblemIds = [],
      specificProblemId,
      allowExhaustion = true
    } = req.body;

    // A. Specific problem requested by ID (e.g. from recommended challenge, catalog, or retry)
    if (specificProblemId) {
      const specific = getProblemById(specificProblemId) || generatedProblemsCache.get(specificProblemId);
      if (specific) {
        generatedProblemsCache.set(specific.id, specific);
        const { hiddenTestCases, solutionCode, ...sanitized } = specific;
        return res.json({
          problem: {
            ...sanitized,
            starterCode: DEFAULT_LANGUAGE_SYNTAX,
            hiddenTestCasesCount: hiddenTestCases.length
          },
          exhausted: false,
          source: 'specific-id'
        });
      }
    }

    // B. Curated 50-Problem Catalog Selection (Guaranteed 100% verified test cases)
    const categoryCandidates = getProblemsByCategoryAndDifficulty(category, difficulty as Difficulty);
    const unattempted = categoryCandidates.filter((p) => !avoidProblemIds.includes(p.id));

    if (unattempted.length > 0) {
      // Pick a random unattempted problem from this category & difficulty
      const selected = unattempted[Math.floor(Math.random() * unattempted.length)];
      generatedProblemsCache.set(selected.id, selected);
      const { hiddenTestCases, solutionCode, ...sanitized } = selected;
      return res.json({
        problem: {
          ...sanitized,
          starterCode: DEFAULT_LANGUAGE_SYNTAX,
          hiddenTestCasesCount: hiddenTestCases.length
        },
        exhausted: false,
        totalRemaining: unattempted.length - 1,
        totalAvailable: categoryCandidates.length,
        source: 'curated-bank'
      });
    }

    // C. If all problems in this specific category & difficulty have been completed:
    if (categoryCandidates.length > 0 && allowExhaustion) {
      // Pick one candidate as a reference for display, but notify user of exhaustion
      const fallbackProblem = categoryCandidates[Math.floor(Math.random() * categoryCandidates.length)];
      generatedProblemsCache.set(fallbackProblem.id, fallbackProblem);
      const { hiddenTestCases, solutionCode, ...sanitized } = fallbackProblem;
      return res.json({
        exhausted: true,
        category,
        difficulty,
        totalAvailable: categoryCandidates.length,
        message: `Outstanding! You have attempted all ${categoryCandidates.length} curated problems in "${category}" (${difficulty}). You can reset your practice history to retry them, or expand to another category!`,
        problem: {
          ...sanitized,
          starterCode: DEFAULT_LANGUAGE_SYNTAX,
          hiddenTestCasesCount: hiddenTestCases.length
        },
        source: 'curated-bank-exhausted'
      });
    }

    // D. If category had no candidates (custom topic), search broader pool or generate with AI validation
    let broadCandidates = CURATED_CODING_PROBLEMS.filter(
      (p) => p.difficulty === difficulty && !avoidProblemIds.includes(p.id)
    );
    if (broadCandidates.length > 0) {
      const selected = broadCandidates[Math.floor(Math.random() * broadCandidates.length)];
      generatedProblemsCache.set(selected.id, selected);
      const { hiddenTestCases, solutionCode, ...sanitized } = selected;
      return res.json({
        problem: {
          ...sanitized,
          starterCode: DEFAULT_LANGUAGE_SYNTAX,
          hiddenTestCasesCount: hiddenTestCases.length
        },
        exhausted: false,
        source: 'curated-bank-difficulty-match'
      });
    }

    // E. AI Question Generation with Rigorous Reference Solution Validation
    if (ai) {
      const prompt = `You are an elite Senior Staff Technical Bar Raiser at a top tier tech company.
Create a unique, realistic algorithm coding problem.
Language: ${language}, Difficulty: ${difficulty}, Category: ${category}, Role: ${jobRole}.
Avoid IDs: ${JSON.stringify(avoidProblemIds)}.

CRITICAL SECURITY & INTEGRITY INSTRUCTIONS:
- "starterCode": MUST BE AN UNSOLVED EMPTY SKELETON WITH ONLY FUNCTION SIGNATURE AND TODO COMMENTS. NEVER PUT THE SOLUTION IN starterCode!
- "solutionCode": working solution for "${language}".
- "publicTestCases": 2 cases with id, input, expectedOutput, description.
- "hiddenTestCases": 3 edge-case test cases with id, input, expectedOutput, description.
Return valid JSON.`;

      try {
        const response = await withTimeout(
          ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents: prompt,
            config: { responseMimeType: 'application/json' }
          }),
          7000
        );

        const rawText = response.text || '';
        let generated: any = null;
        try {
          generated = JSON.parse(rawText);
        } catch {
          const match = rawText.match(/\{[\s\S]*\}/);
          if (match) generated = JSON.parse(match[0]);
        }

        if (generated && generated.title && Array.isArray(generated.publicTestCases)) {
          const problemId = generated.id || `ai-${Date.now().toString(36)}`;
          const internalProblem: InternalCodingProblem = {
            ...generated,
            id: problemId,
            difficulty: difficulty as Difficulty,
            category: category as CodingCategory,
            starterCode: generated.starterCode || {},
            solutionCode: generated.solutionCode || {}
          };

          // Validation pipeline: verify reference solution against generated test cases
          const refCode = internalProblem.solutionCode[language as ProgrammingLanguage];
          if (refCode) {
            const verificationSuite = [
              ...internalProblem.publicTestCases,
              ...(internalProblem.hiddenTestCases || [])
            ];
            const testResult = await runTestCases(
              refCode,
              language as ProgrammingLanguage,
              verificationSuite,
              false
            );

            // If reference solution fails verification, reject AI question and use trusted catalog
            if (testResult.passedTestCases === verificationSuite.length) {
              generatedProblemsCache.set(problemId, internalProblem);
              const { hiddenTestCases, solutionCode, ...sanitized } = internalProblem;
              return res.json({
                problem: {
                  ...sanitized,
                  starterCode: DEFAULT_LANGUAGE_SYNTAX,
                  hiddenTestCasesCount: (hiddenTestCases || []).length
                },
                exhausted: false,
                source: 'gemini-3.8-flash-validated'
              });
            }
          }
        }
      } catch (genErr) {
        console.warn('AI question generation/validation error:', genErr);
      }
    }

    // Ultimate fallback to first curated problem
    const fallback = CURATED_CODING_PROBLEMS[0];
    const { hiddenTestCases, solutionCode, ...sanitized } = fallback;
    return res.json({
      problem: {
        ...sanitized,
        starterCode: DEFAULT_LANGUAGE_SYNTAX,
        hiddenTestCasesCount: hiddenTestCases.length
      },
      exhausted: false,
      source: 'curated-bank-default'
    });
  } catch (err: any) {
    console.error('Error in generate-question:', err);
    const fallback = CURATED_CODING_PROBLEMS[0];
    const { hiddenTestCases, solutionCode, ...sanitized } = fallback;
    return res.json({
      problem: {
        ...sanitized,
        starterCode: DEFAULT_LANGUAGE_SYNTAX,
        hiddenTestCasesCount: hiddenTestCases.length
      },
      exhausted: false,
      source: 'curated-bank-error-fallback'
    });
  }
});

// 5. API: Run Code (Against Public Test Cases or Custom Input)
app.post('/api/coding-interview/run', async (req, res) => {
  try {
    const { code, language = 'python', testCases = [], customInput } = req.body;

    if (!code || typeof code !== 'string') {
      return res.status(400).json({ error: 'Code is required.' });
    }

    // Custom Input Execution
    if (customInput !== undefined) {
      const rawResult = await executeCode({
        code,
        language: language as ProgrammingLanguage,
        input: String(customInput)
      });

      return res.json({
        output: rawResult.stdout,
        error: rawResult.stderr || (rawResult.timedOut ? 'Execution timed out (> 3000ms)' : undefined),
        executionTimeMs: rawResult.executionTimeMs,
        memoryMb: rawResult.memoryMb,
        status: rawResult.exitCode === 0 ? 'success' : 'error'
      });
    }

    // Public Test Cases Execution
    const execResult = await runTestCases(
      code,
      language as ProgrammingLanguage,
      testCases,
      false
    );

    return res.json(execResult);
  } catch (err: any) {
    console.error('Run code error:', err);
    return res.status(500).json({
      status: 'runtime_error',
      output: '',
      runtimeError: err?.message || 'Code execution engine error',
      totalTestCases: 0,
      passedTestCases: 0,
      testResults: [],
      executionTimeMs: 0,
      memoryMb: 0
    });
  }
});

// 6. API: Submit Code (Evaluates Public + Hidden Test Cases)
app.post('/api/coding-interview/submit', async (req, res) => {
  try {
    const { problemId, code, language = 'python', publicTestCases = [] } = req.body;

    if (!code || typeof code !== 'string') {
      return res.status(400).json({ error: 'Code is required.' });
    }

    // Retrieve problem and hidden test cases
    let problem = generatedProblemsCache.get(problemId) || getProblemById(problemId);
    let hiddenTestCases = problem?.hiddenTestCases || [
      { id: 991, input: '100\n100', expectedOutput: '0, 1', description: 'Hidden edge test 1' },
      { id: 992, input: '1 2 3\n5', expectedOutput: '1, 2', description: 'Hidden boundary test 2' }
    ];

    // Build unified test suite
    const fullSuite = [
      ...publicTestCases.map((tc: any) => ({ ...tc, isHidden: false })),
      ...hiddenTestCases.map((tc: any) => ({ ...tc, isHidden: true }))
    ];

    // Execute against all test cases
    const fullResult = await runTestCases(
      code,
      language as ProgrammingLanguage,
      fullSuite,
      true
    );

    // Sanitize output so hidden inputs & expected outputs are NOT exposed
    const sanitizedResults = fullResult.testResults.map((tc) => {
      if (tc.isHidden) {
        return {
          id: tc.id,
          input: '[Hidden on Server]',
          expectedOutput: '[Hidden on Server]',
          actualOutput: tc.passed ? '[Passed]' : '[Failed on hidden constraints]',
          passed: tc.passed,
          executionTimeMs: tc.executionTimeMs,
          memoryMb: tc.memoryMb,
          isHidden: true,
          description: 'Server-side hidden test case'
        };
      }
      return tc;
    });

    return res.json({
      ...fullResult,
      testResults: sanitizedResults,
      hiddenCount: hiddenTestCases.length,
      publicCount: publicTestCases.length
    });
  } catch (err: any) {
    console.error('Submit code error:', err);
    return res.status(500).json({
      status: 'runtime_error',
      output: '',
      runtimeError: err?.message || 'Submission execution failed',
      totalTestCases: 0,
      passedTestCases: 0,
      testResults: [],
      executionTimeMs: 0,
      memoryMb: 0
    });
  }
});

// 7. API: AI Coding Interviewer Interactive Chat
app.post('/api/coding-interview/chat', async (req, res) => {
  try {
    const {
      problem,
      candidateMessage,
      chatHistory = [],
      currentCode = '',
      language = 'python',
      executionResult,
      personaId = 'sarah'
    } = req.body;

    if (!candidateMessage || !candidateMessage.trim()) {
      return res.status(400).json({ error: 'Candidate message is required' });
    }

    if (ai) {
      const personaPrompt = personaId === 'alex'
        ? 'You are Alex Thorne, Principal Systems Architect. You are rigorous, analytical, focus on failure modes, concurrency, scalability, and clean algorithm invariants.'
        : personaId === 'maya'
        ? 'You are Maya Patel, Senior Bar Raiser. You emphasize clear problem decomposition, edge cases, trade-off communication, and optimal complexity.'
        : 'You are Sarah Chen, Staff Engineering Lead. You are encouraging yet probing, challenging inefficient solutions, asking about Big-O trade-offs, and guiding the candidate to articulate their approach before coding.';

      const systemInstruction = `${personaPrompt}
You are conducting a live technical coding interview with a candidate for a Software Engineering role.

Problem Title: ${problem?.title || 'Algorithm Problem'}
Problem Description: ${problem?.description || ''}
Expected Time Complexity: ${problem?.expectedTimeComplexity || 'O(n)'}
Expected SpaceComplexity: ${problem?.expectedSpaceComplexity || 'O(1)'}
Language: ${language}

Candidate's current code in the editor:
\`\`\`${language}
${currentCode.slice(0, 1500)}
\`\`\`

Candidate's latest execution result: ${executionResult ? `${executionResult.status} (${executionResult.passedTestCases}/${executionResult.totalTestCases} passed)` : 'Not run yet'}

Rules for your response:
1. Speak directly in 2-3 concise, natural sentences like a real interviewer over video call.
2. If the candidate describes their approach, assess if it is optimal (e.g. O(n) vs O(n^2)). If inefficient, challenge them politely (e.g., "Can you solve this with a Hash Map or Two Pointers to achieve O(n)?").
3. If they ask for a hint, provide a progressive, conceptual hint without giving away the complete solution.
4. If they ask about complexity, quiz or confirm their Big-O analysis.
5. If tests failed, guide them to examine their boundary conditions or off-by-one errors.
6. Do not write full code blocks unless explicitly requested for an explanation after submission. Keep the conversational feel realistic.`;

      const promptContents = [
        ...chatHistory.slice(-4).map((msg: any) => `${msg.sender === 'candidate' ? 'Candidate' : 'Interviewer'}: ${msg.text}`),
        `Candidate: ${candidateMessage}`,
        `Interviewer:`
      ].join('\n');

      try {
        const response = await withTimeout(
          ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents: promptContents,
            config: {
              systemInstruction,
            },
          }),
          6000
        );

        const replyText = response.text?.trim() || "That's an interesting direction. How would you handle the edge cases when the input is empty or has duplicates?";
        return res.json({
          reply: replyText,
          source: 'gemini-3.8-flash'
        });
      } catch (chatAiErr) {
        console.warn('Interviewer chat AI timeout/error, using domain response engine:', chatAiErr);
      }
    }

    // Local resilient responses for offline or high availability
    const lower = candidateMessage.toLowerCase();
    let reply = "Could you walk me through the step-by-step logic of your approach and what data structure you plan to use?";

    if (lower.includes('hint') || lower.includes('help') || lower.includes('stuck')) {
      reply = `Consider whether storing elements you've already seen in a Hash Map or using a two-pointer window can help reduce the search time from O(n²) down to ${problem?.expectedTimeComplexity || 'O(n)'}.`;
    } else if (lower.includes('complexity') || lower.includes('big o') || lower.includes('time') || lower.includes('space')) {
      reply = `What would be the time and space complexity of your current implementation? Notice how the loop traversals scale with input size.`;
    } else if (lower.includes('hashmap') || lower.includes('hash map') || lower.includes('dictionary') || lower.includes('set')) {
      reply = `Using a Hash Map gives you O(1) average lookup time! How will you handle duplicate keys or values as you iterate?`;
    } else if (lower.includes('pointer') || lower.includes('sort') || lower.includes('sliding window')) {
      reply = `Good instinct. If you sort or advance pointers, how do you ensure you don't miss matching pairs while keeping space complexity at ${problem?.expectedSpaceComplexity || 'O(1)'}?`;
    } else if (lower.includes('ready') || lower.includes('done') || lower.includes('finished')) {
      reply = `Great! Go ahead and run the test cases in the editor. Watch out for boundary conditions such as single-element inputs.`;
    }

    return res.json({
      reply,
      source: 'local-interviewer'
    });
  } catch (err: any) {
    console.error('Interviewer chat error:', err);
    return res.json({
      reply: "Let's focus on the primary constraint. What data structure gives us the fastest lookup for previously visited elements?",
      source: 'fallback'
    });
  }
});

// 8. API: Real-Time Coding Evaluation and AI Code Optimization Suggestions
app.post('/api/coding-interview/evaluate', async (req, res) => {
  try {
    const {
      problem,
      submittedCode,
      language = 'python',
      executionResult,
      mode = 'practice',
      interviewerChat = [],
      timeSpentSeconds = 180
    } = req.body;

    const passedCount = executionResult?.passedTestCases || 0;
    const totalCount = executionResult?.totalTestCases || 1;
    const passRatio = totalCount > 0 ? passedCount / totalCount : 0;

    // Retrieve canonical solution if stored
    const problemObj = generatedProblemsCache.get(problem?.id) || getProblemById(problem?.id);
    const canonicalSolution =
      problemObj?.solutionCode?.[language as ProgrammingLanguage] ||
      problem?.solutionCode?.[language as ProgrammingLanguage] ||
      '';

    if (ai) {
      const evalPrompt = `You are an elite Lead Technical Interview Bar Raiser evaluating a candidate's submitted coding interview solution.
Problem: "${problem?.title}"
Category: "${problem?.category}"
Difficulty: "${problem?.difficulty}"
Expected Time: "${problem?.expectedTimeComplexity}", Expected Space: "${problem?.expectedSpaceComplexity}"
Candidate Language: "${language}"

Candidate's Submitted Code:
\`\`\`${language}
${submittedCode}
\`\`\`

Canonical Correct Solution (for reference):
\`\`\`${language}
${canonicalSolution}
\`\`\`

Test Results: ${passedCount}/${totalCount} test cases passed. Status: ${executionResult?.status}. Execution time: ${executionResult?.executionTimeMs}ms.

Evaluate the solution with strict, realistic bar-raiser scrutiny:
1. "overallScore": integer 0-100. (If user didn't solve or tests failed, score should be low 10-50. If they passed all tests, score 75-95).
2. "functionalCorrectnessScore": integer 0-35.
3. "codeQualityScore": integer 0-15.
4. "problemSolvingScore": integer 0-20.
5. "optimizationScore": integer 0-15.
6. "algorithmKnowledgeScore": integer 0-15.
7. "categoryScores": array of objects { "name": string, "score": number, "maxScore": number, "assessment": string }
8. "whyCodeFailed": string (Clear, direct explanation of why the user's code failed or what mistakes were made so the candidate immediately understands their errors).
9. "mistakesAnalysis": array of 2-4 strings detailing each exact mistake in the candidate's code (e.g. "Line 4: Used nested loop instead of hash table", "Forgot to handle empty list edge case", "Returned string index instead of tuple").
10. "correctSolutionCode": string (Full, working, correct solution code in ${language} that solves the problem perfectly).
11. "optimizationSuggestions":
   - "problemsInCode": array of 2-3 specific issues or edge case vulnerabilities
   - "inefficientLogic": array of 1-2 points on redundant computations or memory allocations
   - "possibleImprovements": array of 2-3 concrete steps to level up this code
   - "optimizedApproach": explanation of the optimal Staff-level algorithm
   - "alternativeAlgorithms": array of 2 alternative methods
   - "timeComplexityComparison": { "current": string, "optimized": string }
   - "spaceComplexityComparison": { "current": string, "optimized": string }
   - "improvedSolutionCode": string (Pristine correct code in ${language})
12. "strongTopics": array of 2-3 skills demonstrated well
13. "weakTopics": array of 1-2 areas to practice
14. "repeatedMistakes": array of 1-2 common pitfalls noticed
15. "recommendedProblems": array of 2 follow-up problems { "title": string, "difficulty": string, "category": string }
16. "personalizedSuggestions": array of 2-3 actionable interview tips

Return ONLY valid JSON matching this schema.`;

      try {
        const response = await withTimeout(
          ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents: evalPrompt,
            config: {
              responseMimeType: 'application/json',
            },
          }),
          7000
        );

        const rawText = response.text || '';
        let evalData: any = null;
        try {
          evalData = JSON.parse(rawText);
        } catch {
          const match = rawText.match(/\{[\s\S]*\}/);
          if (match) evalData = JSON.parse(match[0]);
        }

        if (evalData && typeof evalData.overallScore === 'number') {
          return res.json({
            ...evalData,
            correctSolutionCode: evalData.correctSolutionCode || canonicalSolution || evalData.optimizationSuggestions?.improvedSolutionCode,
            source: 'gemini-3.8-flash'
          });
        }
      } catch (geminiErr) {
        console.warn('Gemini evaluation error, using local evaluation engine:', geminiErr);
      }
    }

    // Local evaluation engine with specific mistake diagnosis
    const baseScore = Math.round(passRatio * 55) + (passedCount > 0 ? 25 : 10);
    const finalScore = Math.min(Math.max(baseScore, 10), 96);

    const mistakes: string[] = [];
    let failureReason = '';

    if (passedCount === 0) {
      if (submittedCode.includes('TODO') || submittedCode.trim().length < 60) {
        failureReason = "Your solution was left uncompleted or retained the template placeholder. Test cases received empty or default output.";
        mistakes.push("The required algorithmic logic was not implemented in the function body.");
        mistakes.push("Placeholder return value did not produce any valid results for the test assertions.");
      } else if (executionResult?.status === 'compile_error') {
        failureReason = `Syntax/Compilation Error: ${executionResult.compilationError || 'Failed syntax verification.'}`;
        mistakes.push("Syntax error prevented the program from running.");
      } else if (executionResult?.status === 'time_limit_exceeded') {
        failureReason = "Time Limit Exceeded (>3000ms): An infinite loop or unbounded recursive traversal occurred.";
        mistakes.push("Loop termination condition was never reached on standard inputs.");
      } else {
        failureReason = "Logical discrepancy: The code executed without crashing, but the computed return values did not match the expected answers.";
        mistakes.push("Incorrect state transitions or index math inside the traversal loop.");
        mistakes.push("Failed to store or retrieve previous elements correctly.");
      }
    } else if (passedCount < totalCount) {
      failureReason = `Passed ${passedCount} of ${totalCount} test cases. The code worked for basic inputs but failed on hidden edge cases (e.g. duplicate elements, negative numbers, or boundary bounds).`;
      mistakes.push("Edge-case vulnerability: Output failed on hidden duplicate numbers or negative integers.");
      mistakes.push("Boundary check missing: Assumed non-empty collections or distinct elements.");
    } else {
      failureReason = "All public and hidden test cases passed successfully! Review the optimized code below for clean idiomatic patterns.";
      mistakes.push("None: Functional requirements and edge cases passed.");
    }

    const fallbackEval = {
      overallScore: finalScore,
      functionalCorrectnessScore: Math.round(passRatio * 35),
      codeQualityScore: passedCount > 0 ? 12 : 5,
      problemSolvingScore: Math.round(passRatio * 18),
      optimizationScore: passedCount > 0 ? 12 : 4,
      algorithmKnowledgeScore: passedCount > 0 ? 13 : 6,
      testCasesPassedRate: `${passedCount}/${totalCount}`,
      whyCodeFailed: failureReason,
      mistakesAnalysis: mistakes,
      correctSolutionCode: canonicalSolution,
      categoryScores: [
        {
          name: 'Functional Correctness & Test Pass Rate',
          score: Math.round(passRatio * 35),
          maxScore: 35,
          assessment: passedCount === totalCount ? 'All public and hidden test cases passed with valid assertions.' : `Passed ${passedCount} of ${totalCount} test cases. Review identified mistakes.`
        },
        {
          name: 'Time & Space Complexity Optimization',
          score: passedCount > 0 ? 12 : 5,
          maxScore: 20,
          assessment: `Target: ${problem?.expectedTimeComplexity || 'O(n)'} time and ${problem?.expectedSpaceComplexity || 'O(n)'} space.`
        },
        {
          name: 'Code Cleanliness & Idiomatic Style',
          score: passedCount > 0 ? 13 : 8,
          maxScore: 20,
          assessment: 'Clean variable naming and coherent execution flow.'
        },
        {
          name: 'Algorithmic Intuition & Data Structure Selection',
          score: passedCount > 0 ? 14 : 6,
          maxScore: 25,
          assessment: 'Primary data structure selection and problem-solving strategy.'
        }
      ],
      optimizationSuggestions: {
        problemsInCode: mistakes,
        inefficientLogic: [
          'Verify time complexity: Avoid nested searches when a single-pass Hash Map can do O(1) lookups.'
        ],
        possibleImprovements: [
          'Study the correct working code provided below to understand how the optimal algorithm handles all constraints.',
          'Always account for boundary conditions: empty inputs, duplicates, and negative numbers.'
        ],
        optimizedApproach: problemObj?.solutionExplanation || `Use a single pass with a Hash Map. In one traversal, calculate the needed complement; if it exists in the hash table, return immediately for optimal ${problem?.expectedTimeComplexity || 'O(n)'} runtime.`,
        alternativeAlgorithms: ['Two Pointers with Sorting', 'Binary Search on Sorted Space'],
        timeComplexityComparison: {
          current: problem?.expectedTimeComplexity || 'O(n)',
          optimized: problem?.expectedTimeComplexity || 'O(n)'
        },
        spaceComplexityComparison: {
          current: problem?.expectedSpaceComplexity || 'O(n)',
          optimized: problem?.expectedSpaceComplexity || 'O(n)'
        },
        improvedSolutionCode: canonicalSolution || submittedCode
      },
      strongTopics: [problem?.category || 'Algorithms', 'Array Traversal'],
      weakTopics: ['Edge-Case Invariants', 'Optimal Hash Mapping'],
      repeatedMistakes: ['Leaving function incomplete or failing to handle edge cases'],
      recommendedProblems: [
        { title: 'Valid Parentheses', difficulty: 'Easy' as Difficulty, category: 'Stack and Queue' },
        { title: 'Longest Substring Without Repeating Characters', difficulty: 'Medium' as Difficulty, category: 'Arrays and Strings' }
      ],
      personalizedSuggestions: [
        'Review the correct code solution below carefully to see how the optimal data structure avoids nested loops.',
        'Trace the code manually with a small sample input before submitting.'
      ],
      source: 'local-bar-raiser'
    };

    return res.json(fallbackEval);
  } catch (err: any) {
    console.error('Coding evaluation error:', err);
    return res.status(500).json({ error: err?.message || 'Failed to evaluate coding submission' });
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  const portNumber = Number(PORT) || 3000;
  app.listen(portNumber, '0.0.0.0', () => {
    console.log(`PrepVertex AI Server running on http://0.0.0.0:${portNumber}`);
  });
}

startServer();
